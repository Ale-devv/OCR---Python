import requests
import re

# 📁 Nome do arquivo PDF
arquivo_pdf = 'PDF_NaoEstruturado.pdf'

# 🔐 Sua chave de API do OCR.Space
API_KEY = 'K86688505188957'

# 📤 Envia o PDF para o OCR.Space
with open(arquivo_pdf, 'rb') as f:
    response = requests.post(
        'https://api.ocr.space/parse/image',
        files={'filename': f},
        data={
            'apikey': API_KEY,
            'language': 'por',
            'isOverlayRequired': False,
            'OCREngine': 2  # OCR Engine 2 geralmente tem melhor precisão
        }
    )

# 📥 Processa a resposta
resultado = response.json()

# Verifica se o OCR foi bem-sucedido
if resultado.get("IsErroredOnProcessing"):
    print("Erro ao processar o OCR:", resultado.get("ErrorMessage"))
else:
    texto = resultado['ParsedResults'][0]['ParsedText']
    print("Texto extraído via OCR.Space:\n")
    print(texto)

    # 🔍 Aplica regex para extrair dados (ajuste conforme necessário)
    dados = re.findall(
        r"(.*?)\nAtendido em: (.*?) - Status: (.*?)\nObservações:(.*?)\n", 
        texto, 
        re.DOTALL
    )

    # 📄 Exibe os dados extraídos
    for pessoa in dados:
        nome = pessoa[0].strip()
        data = pessoa[1].strip()
        status = pessoa[2].strip()
        observacoes = pessoa[3].strip()

        print("\n--- Atendimento ---")
        print(f"Nome: {nome}")
        print(f"Data: {data}")
        print(f"Status: {status}")
        print(f"Observações: {observacoes}")
